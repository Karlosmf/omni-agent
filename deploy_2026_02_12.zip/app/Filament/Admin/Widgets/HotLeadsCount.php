<?php

namespace App\Filament\Admin\Widgets;

use App\Enums\LeadTemperature;
use App\Models\Lead;
use Filament\Widgets\StatsOverviewWidget;
use Filament\Widgets\StatsOverviewWidget\Stat;

class HotLeadsCount extends StatsOverviewWidget
{
    protected function getStats(): array
    {
        return [
            Stat::make('Consultas Calientes', Lead::where('temperature', LeadTemperature::Hot)->count())
                ->description('Requieren atención inmediata')
                ->descriptionIcon('heroicon-m-fire')
                ->color('danger'),
            Stat::make('Atención Necesaria', Lead::where('needs_human_attention', true)->count())
                ->description('Marcados para intervención manual')
                ->descriptionIcon('heroicon-m-exclamation-triangle')
                ->color('warning'),
            Stat::make('Nuevas Consultas', Lead::where('status', 'new')->count())
                ->description('Esperando ser procesadas')
                ->descriptionIcon('heroicon-m-chat-bubble-left-right')
                ->color('info'),
        ];
    }
}
