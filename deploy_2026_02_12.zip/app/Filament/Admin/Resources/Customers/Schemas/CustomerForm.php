<?php

namespace App\Filament\Admin\Resources\Customers\Schemas;

use Filament\Forms\Components\DatePicker;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Schemas\Components\Grid;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Schema;

class CustomerForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->components([
                Section::make('Datos Personales')
                    ->schema([
                        Grid::make(3)
                            ->schema([
                                TextInput::make('name')
                                    ->label('Nombre Completo')
                                    ->required()
                                    ->maxLength(255),
                                TextInput::make('email')
                                    ->email()
                                    ->maxLength(255),
                                TextInput::make('phone')
                                    ->label('Teléfono (WhatsApp)')
                                    ->required()
                                    ->maxLength(255),
                            ]),
                        Grid::make(3)
                            ->schema([
                                TextInput::make('document_number')
                                    ->label('DNI / Documento'),
                                TextInput::make('passport_number')
                                    ->label('Pasaporte'),
                                DatePicker::make('birth_date')
                                    ->label('Fecha de Nacimiento'),
                            ]),
                    ]),
                Section::make('Dirección y Detalles')
                    ->schema([
                        Textarea::make('address')
                            ->label('Domicilio Completo')
                            ->rows(2)
                            ->columnSpanFull(),
                    ])
                    ->collapsible(),
            ]);
    }
}
