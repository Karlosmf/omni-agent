<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Recibo de Pago - #<?php echo e($transaction->id); ?></title>
    <style>
        body {
            font-family: sans-serif;
            font-size: 14px;
            color: #333;
        }

        .header {
            width: 100%;
            border-bottom: 2px solid #ddd;
            padding-bottom: 20px;
            margin-bottom: 20px;
        }

        .logo {
            max-width: 200px;
        }

        .company-info {
            text-align: right;
            float: right;
        }

        .title {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 5px;
            color: #2d3748;
        }

        .details {
            margin-bottom: 20px;
        }

        .details-table {
            width: 100%;
            border-collapse: collapse;
        }

        .details-table th,
        .details-table td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }

        .total {
            font-size: 18px;
            font-weight: bold;
            text-align: right;
            margin-top: 20px;
        }

        .notes {
            margin-top: 30px;
            font-style: italic;
            color: #666;
            width: 100%;
            border: 1px dashed #ccc;
            padding: 10px;
        }

        .footer {
            margin-top: 50px;
            text-align: center;
            font-size: 12px;
            color: #999;
        }
    </style>
</head>

<body>

    <div class="header">
        <div class="company-info">
            <strong>Luopan Viajes & Turismo</strong><br>
            Belgrano 843, Local A<br>
            Reconquista, Santa Fe 3560<br>
            Nela: +54 9 3482 30-0052<br>
            Belén: +54 9 3482 60-0801
        </div>
        <img src="<?php echo e(public_path('images/branding/logo-full.png')); ?>" alt="Luopan Logo" class="logo">
    </div>

    <div class="title">RECIBO DE PAGO</div>
    <div>Fecha: <?php echo e($transaction->created_at->format('d/m/Y H:i')); ?></div>
    <div>Nro. Transacción: #<?php echo e($transaction->id); ?></div>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($transaction->booking): ?>
        <div class="mb-4">
            <p><strong>Expediente:</strong> <?php echo e($transaction->booking->file_number); ?></p>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($transaction->booking->client): ?>
                <p><strong>Cliente:</strong> <?php echo e($transaction->booking->client->name); ?></p>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <p><strong>Destino:</strong> <?php echo e($transaction->booking->destination); ?></p>
            <p><strong>Fecha Salida:</strong>
                <?php echo e($transaction->booking->start_date ? \Carbon\Carbon::parse($transaction->booking->start_date)->format('d/m/Y') : '-'); ?>

            </p>
        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($transaction->payer_name): ?>
        <div class="mb-4">
            <p><strong>Pagante / Beneficiario:</strong> <?php echo e($transaction->payer_name); ?></p>
        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <table class="details-table">
        <thead>
            <tr>
                <th>Concepto</th>
                <th style="text-align: right;">Importe</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td><?php echo e($transaction->notes ?? 'Pago a cuenta por expediente ' . $transaction->booking->file_number); ?>

                </td>
                <td style="text-align: right;">
                    <?php echo e($transaction->currency == \App\Enums\Currency::USD ? 'USD' : 'ARS'); ?>

                    <?php echo e(number_format($transaction->amount, 2)); ?>

                </td>
            </tr>
        </tbody>
    </table>

    <div class="total">
        Total Pagado: <?php echo e($transaction->currency == \App\Enums\Currency::USD ? 'USD' : 'ARS'); ?>

        <?php echo e(number_format($transaction->amount, 2)); ?>

    </div>

    <div class="notes">
        <strong>Método de Pago:</strong> <?php echo e($transaction->method); ?><br>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($transaction->exchange_rate > 1): ?>
            <strong>Tipo de Cambio Ref:</strong> <?php echo e(number_format($transaction->exchange_rate, 2)); ?><br>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($transaction->amount_usd_fixed > 0 && $transaction->currency != \App\Enums\Currency::USD): ?>
            <strong>Equivalente USD:</strong> USD <?php echo e(number_format($transaction->amount_usd_fixed, 2)); ?>

        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>

    <div class="footer">
        Gracias por confiar en Luopan Viajes & Turismo. <br>
        Este documento es un comprobante de pago no fiscal.
    </div>

</body>

</html><?php /**PATH /Users/carlitos/Projects/omni-agent/resources/views/pdf/receipt.blade.php ENDPATH**/ ?>