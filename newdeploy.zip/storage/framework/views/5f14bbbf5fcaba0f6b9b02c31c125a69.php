<!DOCTYPE html>
<html>

<head>
    <title>Balance Anual <?php echo e($year); ?></title>
    <style>
        body {
            font-family: sans-serif;
        }

        .header {
            text-align: center;
            margin-bottom: 30px;
        }

        .logo {
            font-size: 24px;
            font-weight: bold;
            color: #008069;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: right;
        }

        th {
            background-color: #f2f2f2;
            text-align: center;
        }

        .text-left {
            text-align: left;
        }

        .total-row {
            font-weight: bold;
            background-color: #e6e6e6;
        }

        .income {
            color: #22c55e;
        }

        .expense {
            color: #ef4444;
        }
    </style>
</head>

<body>
    <div class="header">
        <div class="logo">LUOPAN VIAJES</div>
        <h3>Reporte de Balance Anual - <?php echo e($year); ?></h3>
        <p>Generado el: <?php echo e(now()->format('d/m/Y H:i')); ?></p>
    </div>

    <table>
        <thead>
            <tr>
                <th class="text-left">Mes</th>
                <th>Ingresos (<?php echo e($currency); ?>)</th>
                <th>Egresos (<?php echo e($currency); ?>)</th>
                <th>Balance Neto</th>
            </tr>
        </thead>
        <tbody>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $monthlyData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="text-left"><?php echo e($data['label']); ?></td>
                    <td class="income"><?php echo e(number_format($data['income'], 2)); ?></td>
                    <td class="expense"><?php echo e(number_format($data['expense'], 2)); ?></td>
                    <td style="color: <?php echo e($data['balance'] >= 0 ? 'black' : 'red'); ?>">
                        <?php echo e(number_format($data['balance'], 2)); ?>

                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <tr class="total-row">
                <td class="text-left">TOTAL ANUAL</td>
                <td class="income"><?php echo e(number_format($totals['income'], 2)); ?></td>
                <td class="expense"><?php echo e(number_format($totals['expense'], 2)); ?></td>
                <td><?php echo e(number_format($totals['balance'], 2)); ?></td>
            </tr>
        </tbody>
    </table>
</body>

</html><?php /**PATH /Users/carlitos/Projects/omni-agent/resources/views/reports/balance-sheet-pdf.blade.php ENDPATH**/ ?>