<h2
    <?php echo e($attributes->class(['fi-modal-heading'])); ?>

>
    <?php echo e($slot); ?>

</h2>
<?php /**PATH /Users/carlitos/Projects/omni-agent/vendor/filament/support/resources/views/components/modal/heading.blade.php ENDPATH**/ ?>