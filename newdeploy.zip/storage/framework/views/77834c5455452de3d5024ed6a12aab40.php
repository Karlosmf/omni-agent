<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>Expediente de Viaje #<?php echo e($booking->file_number); ?></title>
    <style>
        body {
            font-family: 'DejaVu Sans', sans-serif;
            font-size: 12px;
            color: #333;
        }

        .header {
            width: 100%;
            border-bottom: 2px solid #075E54;
            margin-bottom: 20px;
            padding-bottom: 10px;
        }

        .logo {
            font-size: 24px;
            font-weight: bold;
            color: #075E54;
        }

        .company-info {
            float: right;
            text-align: right;
        }

        .title {
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 10px;
        }

        .section {
            margin-bottom: 20px;
        }

        .grid {
            width: 100%;
            margin-bottom: 15px;
        }

        .grid td {
            vertical-align: top;
        }

        .label {
            font-weight: bold;
            color: #555;
        }

        table.items {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }

        table.items th,
        table.items td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        table.items th {
            background-color: #f2f2f2;
            color: #333;
        }

        .total-row td {
            font-weight: bold;
            background-color: #eee;
        }

        .footer {
            position: fixed;
            bottom: 0;
            width: 100%;
            text-align: center;
            font-size: 10px;
            color: #777;
            border-top: 1px solid #ddd;
            padding-top: 10px;
        }
    </style>
</head>

<body>

    <div class="header">
        <table width="100%">
            <tr>
                <td class="logo">Luopan Viajes</td>
                <td class="company-info">
                    Legajo #1234<br>
                    Av. Corrientes 1234, CABA<br>
                    contacto@luopan.com
                </td>
            </tr>
        </table>
    </div>

    <div class="section">
        <div class="title">Detalle del Expediente</div>
        <table class="grid">
            <tr>
                <td width="50%">
                    <span class="label">Nro Expediente:</span> <?php echo e($booking->file_number); ?><br>
                    <span class="label">Fecha Emisión:</span> <?php echo e(now()->format('d/m/Y')); ?><br>
                    <span class="label">Estado:</span> <?php echo e($booking->status->getLabel()); ?>

                </td>
                <td width="50%">
                    <span class="label">Titular:</span> <?php echo e($booking->holder_name); ?><br>
                    <span class="label">Fecha Viaje:</span> <?php echo e($booking->travel_date->format('d/m/Y')); ?><br>
                    <span class="label">Contacto:</span> <?php echo e($booking->lead?->customer_phone ?? 'N/A'); ?>

                </td>
            </tr>
        </table>
    </div>

    <div class="section">
        <div class="title">Servicios Contratados</div>
        <table class="items">
            <thead>
                <tr>
                    <th>Tipo</th>
                    <th>Descripción</th>
                    <th>Proveedor</th>
                    <th align="right">Precio</th>
                </tr>
            </thead>
            <tbody>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $booking->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->service_type->getLabel()); ?></td>
                        <td><?php echo e($item->description); ?></td>
                        <td><?php echo e($item->supplier?->name ?? $item->supplier_name); ?></td>
                        <td align="right"><?php echo e($item->currency); ?> <?php echo e(number_format($item->sell, 2)); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <tr class="total-row">
                    <td colspan="3" align="right">TOTAL</td>
                    <td align="right"><?php echo e($booking->currency); ?> <?php echo e(number_format($booking->total_sell, 2)); ?></td>
                </tr>
            </tbody>
        </table>
    </div>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($booking->transactions->isNotEmpty()): ?>
        <div class="section">
            <div class="title">Pagos Registrados</div>
            <table class="items">
                <thead>
                    <tr>
                        <th>Fecha</th>
                        <th>Método</th>
                        <th>Moneda Orig.</th>
                        <th align="right">Monto (USD)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $booking->transactions->where('type', \App\Enums\TransactionType::Cobro); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($trx->created_at->format('d/m/Y')); ?></td>
                            <td><?php echo e($trx->method); ?></td>
                            <td><?php echo e($trx->amount); ?> <?php echo e($trx->currency->value); ?></td>
                            <td align="right">USD <?php echo e(number_format($trx->amount_usd_fixed, 2)); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <div class="footer">
        Este documento es un comprobante no fiscal emitido por el sistema Omni-Agent.<br>
        Gracias por confiar en Luopan Viajes.
    </div>

</body>

</html><?php /**PATH /Users/carlitos/Projects/omni-agent/resources/views/pdf/booking.blade.php ENDPATH**/ ?>