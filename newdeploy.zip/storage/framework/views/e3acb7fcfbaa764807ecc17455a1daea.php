<div <?php echo e($attributes->class(['fi-btn-group'])); ?>>
    <?php echo e($slot); ?>

</div>
<?php /**PATH /Users/carlitos/Projects/omni-agent/vendor/filament/support/resources/views/components/button/group.blade.php ENDPATH**/ ?>