<p
    <?php echo e($attributes->class(['fi-section-header-description'])); ?>

>
    <?php echo e($slot); ?>

</p>
<?php /**PATH /Users/carlitos/Projects/omni-agent/vendor/filament/support/resources/views/components/section/description.blade.php ENDPATH**/ ?>