<p
    <?php echo e($attributes->class(['fi-modal-description'])); ?>

>
    <?php echo e($slot); ?>

</p>
<?php /**PATH /Users/carlitos/Projects/omni-agent/vendor/filament/support/resources/views/components/modal/description.blade.php ENDPATH**/ ?>