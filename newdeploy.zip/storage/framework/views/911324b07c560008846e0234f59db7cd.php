<?php echo e(\Filament\Support\generate_loading_indicator_html($attributes)); ?>

<?php /**PATH /Users/carlitos/Projects/omni-agent/vendor/filament/support/resources/views/components/loading-indicator.blade.php ENDPATH**/ ?>