<div class="filament-widget">
    <?php if (isset($component)) { $__componentOriginalee08b1367eba38734199cf7829b1d1e9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalee08b1367eba38734199cf7829b1d1e9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.section.index','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
         <?php $__env->slot('heading', null, []); ?> 
            <div class="flex items-center gap-2">
                <svg class="w-5 h-5 text-gray-500" style="width: 20px; height: 20px;" fill="none" stroke="currentColor"
                    viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                </svg>
                <span>Próximos Vencimientos (30 días)</span>
            </div>
         <?php $__env->endSlot(); ?>

        <?php
            $trips = $this->getUpcomingTrips();
        ?>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(count($trips) > 0): ?>
            <div class="space-y-3">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $trips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="flex items-center justify-between p-3 rounded-lg border dark:border-gray-700
                                        <?php if($trip['days_until'] <= 7): ?> bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800
                                        <?php elseif($trip['days_until'] <= 15): ?> bg-yellow-50 dark:bg-yellow-900/20 border-yellow-200 dark:border-yellow-800
                                        <?php else: ?> bg-gray-50 dark:bg-gray-800
                                        <?php endif; ?>">
                        <div class="flex-1">
                            <div class="font-semibold text-gray-900 dark:text-gray-100">
                                <?php echo e($trip['file_number']); ?> - <?php echo e($trip['holder_name']); ?>

                            </div>
                            <div class="text-sm text-gray-600 dark:text-gray-400">
                                Viaje: <?php echo e($trip['travel_date']->format('d/m/Y')); ?>

                            </div>
                        </div>
                        <div class="text-right">
                            <div class="text-lg font-bold
                                                <?php if($trip['days_until'] <= 7): ?> text-red-600 dark:text-red-400
                                                <?php elseif($trip['days_until'] <= 15): ?> text-yellow-600 dark:text-yellow-400
                                                <?php else: ?> text-gray-600 dark:text-gray-400
                                                <?php endif; ?>">
                                <?php echo e(abs($trip['days_until'])); ?> días
                            </div>
                            <div class="text-xs text-gray-500 dark:text-gray-400">
                                <?php echo e($trip['status']->getLabel()); ?>

                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        <?php else: ?>
            <div class="text-center py-8 text-gray-500 dark:text-gray-400">
                No hay viajes programados en los próximos 30 días
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalee08b1367eba38734199cf7829b1d1e9)): ?>
<?php $attributes = $__attributesOriginalee08b1367eba38734199cf7829b1d1e9; ?>
<?php unset($__attributesOriginalee08b1367eba38734199cf7829b1d1e9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalee08b1367eba38734199cf7829b1d1e9)): ?>
<?php $component = $__componentOriginalee08b1367eba38734199cf7829b1d1e9; ?>
<?php unset($__componentOriginalee08b1367eba38734199cf7829b1d1e9); ?>
<?php endif; ?>
</div><?php /**PATH /Users/carlitos/Projects/omni-agent/resources/views/filament/admin/widgets/upcoming-deadlines-widget.blade.php ENDPATH**/ ?>