<?php return array (
  'livewireComponents' => 
  array (
    'app.filament.admin.resources.bookings.pages.create-booking' => 'App\\Filament\\Admin\\Resources\\Bookings\\Pages\\CreateBooking',
    'app.filament.admin.resources.bookings.pages.edit-booking' => 'App\\Filament\\Admin\\Resources\\Bookings\\Pages\\EditBooking',
    'app.filament.admin.resources.bookings.pages.list-bookings' => 'App\\Filament\\Admin\\Resources\\Bookings\\Pages\\ListBookings',
    'app.filament.admin.resources.customers.pages.create-customer' => 'App\\Filament\\Admin\\Resources\\Customers\\Pages\\CreateCustomer',
    'app.filament.admin.resources.customers.pages.edit-customer' => 'App\\Filament\\Admin\\Resources\\Customers\\Pages\\EditCustomer',
    'app.filament.admin.resources.customers.pages.list-customers' => 'App\\Filament\\Admin\\Resources\\Customers\\Pages\\ListCustomers',
    'app.filament.admin.resources.customers.relation-managers.bookings-relation-manager' => 'App\\Filament\\Admin\\Resources\\Customers\\RelationManagers\\BookingsRelationManager',
    'app.filament.admin.resources.financial-accounts.pages.create-financial-account' => 'App\\Filament\\Admin\\Resources\\FinancialAccounts\\Pages\\CreateFinancialAccount',
    'app.filament.admin.resources.financial-accounts.pages.edit-financial-account' => 'App\\Filament\\Admin\\Resources\\FinancialAccounts\\Pages\\EditFinancialAccount',
    'app.filament.admin.resources.financial-accounts.pages.list-financial-accounts' => 'App\\Filament\\Admin\\Resources\\FinancialAccounts\\Pages\\ListFinancialAccounts',
    'app.filament.admin.resources.leads.pages.create-lead' => 'App\\Filament\\Admin\\Resources\\Leads\\Pages\\CreateLead',
    'app.filament.admin.resources.leads.pages.edit-lead' => 'App\\Filament\\Admin\\Resources\\Leads\\Pages\\EditLead',
    'app.filament.admin.resources.leads.pages.list-leads' => 'App\\Filament\\Admin\\Resources\\Leads\\Pages\\ListLeads',
    'app.filament.admin.resources.quotations.pages.create-quotation' => 'App\\Filament\\Admin\\Resources\\Quotations\\Pages\\CreateQuotation',
    'app.filament.admin.resources.quotations.pages.edit-quotation' => 'App\\Filament\\Admin\\Resources\\Quotations\\Pages\\EditQuotation',
    'app.filament.admin.resources.quotations.pages.list-quotations' => 'App\\Filament\\Admin\\Resources\\Quotations\\Pages\\ListQuotations',
    'app.filament.admin.resources.quotations.pages.view-quotation' => 'App\\Filament\\Admin\\Resources\\Quotations\\Pages\\ViewQuotation',
    'app.filament.admin.resources.suppliers.pages.create-supplier' => 'App\\Filament\\Admin\\Resources\\Suppliers\\Pages\\CreateSupplier',
    'app.filament.admin.resources.suppliers.pages.edit-supplier' => 'App\\Filament\\Admin\\Resources\\Suppliers\\Pages\\EditSupplier',
    'app.filament.admin.resources.suppliers.pages.list-suppliers' => 'App\\Filament\\Admin\\Resources\\Suppliers\\Pages\\ListSuppliers',
    'app.filament.admin.resources.suppliers.relation-managers.transactions-relation-manager' => 'App\\Filament\\Admin\\Resources\\Suppliers\\RelationManagers\\TransactionsRelationManager',
    'app.filament.admin.resources.transaction-categories.pages.create-transaction-category' => 'App\\Filament\\Admin\\Resources\\TransactionCategories\\Pages\\CreateTransactionCategory',
    'app.filament.admin.resources.transaction-categories.pages.edit-transaction-category' => 'App\\Filament\\Admin\\Resources\\TransactionCategories\\Pages\\EditTransactionCategory',
    'app.filament.admin.resources.transaction-categories.pages.list-transaction-categories' => 'App\\Filament\\Admin\\Resources\\TransactionCategories\\Pages\\ListTransactionCategories',
    'app.filament.admin.resources.transactions.pages.create-transaction' => 'App\\Filament\\Admin\\Resources\\Transactions\\Pages\\CreateTransaction',
    'app.filament.admin.resources.transactions.pages.edit-transaction' => 'App\\Filament\\Admin\\Resources\\Transactions\\Pages\\EditTransaction',
    'app.filament.admin.resources.transactions.pages.list-transactions' => 'App\\Filament\\Admin\\Resources\\Transactions\\Pages\\ListTransactions',
    'app.filament.admin.resources.users.pages.create-user' => 'App\\Filament\\Admin\\Resources\\Users\\Pages\\CreateUser',
    'app.filament.admin.resources.users.pages.edit-user' => 'App\\Filament\\Admin\\Resources\\Users\\Pages\\EditUser',
    'app.filament.admin.resources.users.pages.list-users' => 'App\\Filament\\Admin\\Resources\\Users\\Pages\\ListUsers',
    'app.filament.admin.pages.financial-reports' => 'App\\Filament\\Admin\\Pages\\FinancialReports',
    'filament.pages.dashboard' => 'Filament\\Pages\\Dashboard',
    'app.filament.admin.widgets.ai-insights-widget' => 'App\\Filament\\Admin\\Widgets\\AiInsightsWidget',
    'app.filament.admin.widgets.current-month-balance' => 'App\\Filament\\Admin\\Widgets\\CurrentMonthBalance',
    'app.filament.admin.widgets.dashboard-shortcuts' => 'App\\Filament\\Admin\\Widgets\\DashboardShortcuts',
    'app.filament.admin.widgets.financial-accounts-overview' => 'App\\Filament\\Admin\\Widgets\\FinancialAccountsOverview',
    'app.filament.admin.widgets.hot-leads-count' => 'App\\Filament\\Admin\\Widgets\\HotLeadsCount',
    'app.filament.admin.widgets.monthly-budget-chart' => 'App\\Filament\\Admin\\Widgets\\MonthlyBudgetChart',
    'app.filament.admin.widgets.monthly-sales-chart' => 'App\\Filament\\Admin\\Widgets\\MonthlySalesChart',
    'app.filament.admin.widgets.recent-transactions' => 'App\\Filament\\Admin\\Widgets\\RecentTransactions',
    'app.filament.admin.widgets.supplier-debts-widget' => 'App\\Filament\\Admin\\Widgets\\SupplierDebtsWidget',
    'app.filament.admin.widgets.supplier-stats' => 'App\\Filament\\Admin\\Widgets\\SupplierStats',
    'app.filament.admin.widgets.upcoming-deadlines-widget' => 'App\\Filament\\Admin\\Widgets\\UpcomingDeadlinesWidget',
    'app.filament.admin.widgets.upcoming-departures' => 'App\\Filament\\Admin\\Widgets\\UpcomingDepartures',
    'filament.widgets.account-widget' => 'Filament\\Widgets\\AccountWidget',
    'filament.livewire.database-notifications' => 'Filament\\Livewire\\DatabaseNotifications',
    'filament.auth.pages.edit-profile' => 'Filament\\Auth\\Pages\\EditProfile',
    'filament.livewire.global-search' => 'Filament\\Livewire\\GlobalSearch',
    'filament.livewire.notifications' => 'Filament\\Livewire\\Notifications',
    'filament.livewire.sidebar' => 'Filament\\Livewire\\Sidebar',
    'filament.livewire.simple-user-menu' => 'Filament\\Livewire\\SimpleUserMenu',
    'filament.livewire.topbar' => 'Filament\\Livewire\\Topbar',
    'filament.auth.pages.login' => 'Filament\\Auth\\Pages\\Login',
  ),
  'clusters' => 
  array (
  ),
  'clusteredComponents' => 
  array (
  ),
  'clusterDirectories' => 
  array (
  ),
  'clusterNamespaces' => 
  array (
  ),
  'pages' => 
  array (
    '/Users/carlitos/Projects/omni-agent/app/Filament/Admin/Pages/FinancialReports.php' => 'App\\Filament\\Admin\\Pages\\FinancialReports',
    0 => 'Filament\\Pages\\Dashboard',
  ),
  'pageDirectories' => 
  array (
    0 => '/Users/carlitos/Projects/omni-agent/app/Filament/Admin/Pages',
  ),
  'pageNamespaces' => 
  array (
    0 => 'App\\Filament\\Admin\\Pages',
  ),
  'resources' => 
  array (
    '/Users/carlitos/Projects/omni-agent/app/Filament/Admin/Resources/Bookings/BookingResource.php' => 'App\\Filament\\Admin\\Resources\\Bookings\\BookingResource',
    '/Users/carlitos/Projects/omni-agent/app/Filament/Admin/Resources/Customers/CustomerResource.php' => 'App\\Filament\\Admin\\Resources\\Customers\\CustomerResource',
    '/Users/carlitos/Projects/omni-agent/app/Filament/Admin/Resources/FinancialAccounts/FinancialAccountResource.php' => 'App\\Filament\\Admin\\Resources\\FinancialAccounts\\FinancialAccountResource',
    '/Users/carlitos/Projects/omni-agent/app/Filament/Admin/Resources/Leads/LeadResource.php' => 'App\\Filament\\Admin\\Resources\\Leads\\LeadResource',
    '/Users/carlitos/Projects/omni-agent/app/Filament/Admin/Resources/Quotations/QuotationResource.php' => 'App\\Filament\\Admin\\Resources\\Quotations\\QuotationResource',
    '/Users/carlitos/Projects/omni-agent/app/Filament/Admin/Resources/Suppliers/SupplierResource.php' => 'App\\Filament\\Admin\\Resources\\Suppliers\\SupplierResource',
    '/Users/carlitos/Projects/omni-agent/app/Filament/Admin/Resources/TransactionCategories/TransactionCategoryResource.php' => 'App\\Filament\\Admin\\Resources\\TransactionCategories\\TransactionCategoryResource',
    '/Users/carlitos/Projects/omni-agent/app/Filament/Admin/Resources/Transactions/TransactionResource.php' => 'App\\Filament\\Admin\\Resources\\Transactions\\TransactionResource',
    '/Users/carlitos/Projects/omni-agent/app/Filament/Admin/Resources/Users/UserResource.php' => 'App\\Filament\\Admin\\Resources\\Users\\UserResource',
  ),
  'resourceDirectories' => 
  array (
    0 => '/Users/carlitos/Projects/omni-agent/app/Filament/Admin/Resources',
  ),
  'resourceNamespaces' => 
  array (
    0 => 'App\\Filament\\Admin\\Resources',
  ),
  'widgets' => 
  array (
    '/Users/carlitos/Projects/omni-agent/app/Filament/Admin/Widgets/AiInsightsWidget.php' => 'App\\Filament\\Admin\\Widgets\\AiInsightsWidget',
    '/Users/carlitos/Projects/omni-agent/app/Filament/Admin/Widgets/CurrentMonthBalance.php' => 'App\\Filament\\Admin\\Widgets\\CurrentMonthBalance',
    '/Users/carlitos/Projects/omni-agent/app/Filament/Admin/Widgets/DashboardShortcuts.php' => 'App\\Filament\\Admin\\Widgets\\DashboardShortcuts',
    '/Users/carlitos/Projects/omni-agent/app/Filament/Admin/Widgets/FinancialAccountsOverview.php' => 'App\\Filament\\Admin\\Widgets\\FinancialAccountsOverview',
    '/Users/carlitos/Projects/omni-agent/app/Filament/Admin/Widgets/HotLeadsCount.php' => 'App\\Filament\\Admin\\Widgets\\HotLeadsCount',
    '/Users/carlitos/Projects/omni-agent/app/Filament/Admin/Widgets/MonthlyBudgetChart.php' => 'App\\Filament\\Admin\\Widgets\\MonthlyBudgetChart',
    '/Users/carlitos/Projects/omni-agent/app/Filament/Admin/Widgets/MonthlySalesChart.php' => 'App\\Filament\\Admin\\Widgets\\MonthlySalesChart',
    '/Users/carlitos/Projects/omni-agent/app/Filament/Admin/Widgets/RecentTransactions.php' => 'App\\Filament\\Admin\\Widgets\\RecentTransactions',
    '/Users/carlitos/Projects/omni-agent/app/Filament/Admin/Widgets/SupplierDebtsWidget.php' => 'App\\Filament\\Admin\\Widgets\\SupplierDebtsWidget',
    '/Users/carlitos/Projects/omni-agent/app/Filament/Admin/Widgets/SupplierStats.php' => 'App\\Filament\\Admin\\Widgets\\SupplierStats',
    '/Users/carlitos/Projects/omni-agent/app/Filament/Admin/Widgets/UpcomingDeadlinesWidget.php' => 'App\\Filament\\Admin\\Widgets\\UpcomingDeadlinesWidget',
    '/Users/carlitos/Projects/omni-agent/app/Filament/Admin/Widgets/UpcomingDepartures.php' => 'App\\Filament\\Admin\\Widgets\\UpcomingDepartures',
    0 => 'Filament\\Widgets\\AccountWidget',
  ),
  'widgetDirectories' => 
  array (
    0 => '/Users/carlitos/Projects/omni-agent/app/Filament/Admin/Widgets',
  ),
  'widgetNamespaces' => 
  array (
    0 => 'App\\Filament\\Admin\\Widgets',
  ),
);