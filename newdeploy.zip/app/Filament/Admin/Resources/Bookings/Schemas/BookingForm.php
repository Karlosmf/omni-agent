<?php

namespace App\Filament\Admin\Resources\Bookings\Schemas;

use App\Enums\BookingStatus;
use App\Enums\Currency;
use App\Enums\ServiceType;
use Filament\Forms\Components\DatePicker;
use Filament\Forms\Components\Repeater;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Schemas\Components\Grid;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Components\Utilities\Get;
use Filament\Schemas\Components\Utilities\Set;
use Filament\Schemas\Schema;

class BookingForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->components([
                Section::make('Información General')
                    ->columnSpanFull()
                    ->schema([
                        Grid::make(3)
                            ->schema([
                                Select::make('customer_id')
                                    ->label('Cliente (Cuenta)')
                                    ->relationship('customer', 'name')
                                    ->getOptionLabelFromRecordUsing(fn($record) => "{$record->name} ({$record->email})")
                                    ->searchable()
                                    ->preload()
                                    ->createOptionForm([
                                        TextInput::make('name')
                                            ->label('Nombre')
                                            ->required(),
                                        TextInput::make('phone')
                                            ->label('Teléfono')
                                            ->required(),
                                    ])
                                    ->required(),
                                TextInput::make('file_number')
                                    ->label('Nro File')
                                    ->placeholder('Generado automáticamente')
                                    ->disabledOn('create')
                                    ->unique(ignoreRecord: true),
                                Select::make('status')
                                    ->label('Estado')
                                    ->options(BookingStatus::class)
                                    ->required(),
                            ]),
                        Grid::make(3)
                            ->schema([
                                Select::make('lead_id')
                                    ->label('Lead Origen')
                                    ->relationship('lead', 'customer_name')
                                    ->searchable()
                                    ->preload(),
                                TextInput::make('holder_name')
                                    ->label('Nombre del Pasajero Principal')
                                    ->required(),
                                DatePicker::make('travel_date')
                                    ->label('Fecha de Viaje')
                                    ->required(),
                            ]),
                        \Filament\Forms\Components\Textarea::make('internal_notes')
                            ->label('Notas Internas')
                            ->placeholder('Notas privadas para el equipo (no visibles para el cliente)')
                            ->rows(3)
                            ->columnSpanFull()
                            ->helperText('Estas notas solo son visibles para el equipo administrativo.'),
                    ]),

                Section::make('Servicios / Items')
                    ->columnSpanFull()
                    ->schema([
                        Repeater::make('items')
                            ->label('Servicios Detallados')
                            ->relationship('items')
                            ->schema([
                                Grid::make(4)
                                    ->schema([
                                        Select::make('service_type')
                                            ->label('Tipo')
                                            ->options(ServiceType::class)
                                            ->required(),
                                        TextInput::make('description')
                                            ->label('Descripción')
                                            ->required()
                                            ->columnSpan(3),
                                    ]),

                                Grid::make(4)
                                    ->schema([
                                        Select::make('supplier_id')
                                            ->label('Proveedor')
                                            ->relationship('supplier', 'name')
                                            ->searchable()
                                            ->preload()
                                            ->createOptionForm([
                                                TextInput::make('name')
                                                    ->label('Nombre Proveedor')
                                                    ->required(),
                                                TextInput::make('category')
                                                    ->label('Categoría'),
                                            ])
                                            ->required(),

                                        Select::make('currency')
                                            ->label('Moneda')
                                            ->options(Currency::class)
                                            ->default(Currency::USD->value)
                                            ->required()
                                            ->live()
                                            ->afterStateUpdated(fn(Set $set, Get $get) => self::updateTotals($set, $get)),

                                        TextInput::make('exchange_rate')
                                            ->label('Cotización Origen')
                                            ->numeric()
                                            ->default(1.00)
                                            ->required()
                                            ->live(onBlur: true)
                                            ->visible(fn(Get $get) => self::getCurrencyLabel($get('currency')) !== 'USD')
                                            ->afterStateUpdated(fn(Set $set, Get $get) => self::updateTotals($set, $get)),

                                        TextInput::make('cost')
                                            ->label(fn(Get $get) => 'Costo (' . (self::getCurrencyLabel($get('currency'))) . ')')
                                            ->numeric()
                                            ->prefix('$')
                                            ->required()
                                            ->live(onBlur: true)
                                            ->afterStateUpdated(fn(Set $set, Get $get) => self::updateTotals($set, $get)),

                                        TextInput::make('sell')
                                            ->label(fn(Get $get) => 'Venta (' . (self::getCurrencyLabel($get('currency'))) . ')')
                                            ->numeric()
                                            ->prefix('$')
                                            ->required()
                                            ->live(onBlur: true)
                                            ->afterStateUpdated(fn(Set $set, Get $get) => self::updateTotals($set, $get)),
                                    ]),
                            ])
                            ->columns(1)
                            ->itemLabel(function (array $state): ?string {
                                $type = $state['service_type'] ?? null;
                                $label = $type instanceof ServiceType ? $type->getLabel() : $type;

                                return $label . ': ' . ($state['description'] ?? '');
                            })
                            ->deleteAction(fn(Set $set, Get $get) => self::updateTotals($set, $get)),
                    ]),

                Section::make('Resumen Financiero')
                    ->columnSpanFull()
                    ->schema([
                        // ARS Summary
                        Grid::make(3)
                            ->schema([
                                TextInput::make('total_cost_ars_display')
                                    ->label('Costo Total (ARS)')
                                    ->numeric()
                                    ->prefix('$')
                                    ->readOnly()
                                    ->extraInputAttributes(['class' => 'bg-gray-100']),
                                TextInput::make('total_sell_ars_display')
                                    ->label('Venta Total (ARS)')
                                    ->numeric()
                                    ->prefix('$')
                                    ->readOnly()
                                    ->extraInputAttributes(['class' => 'bg-gray-100']),
                                TextInput::make('profit_ars_display')
                                    ->label('Ganancia (ARS)')
                                    ->numeric()
                                    ->prefix('$')
                                    ->readOnly()
                                    ->extraInputAttributes(['class' => 'bg-gray-100 font-bold text-success-600']),
                            ]),

                        // USD Summary
                        Grid::make(3)
                            ->schema([
                                TextInput::make('total_cost') // Mapped to DB total_cost
                                    ->label('Costo Total (USD)')
                                    ->numeric()
                                    ->prefix('USD')
                                    ->readOnly()
                                    ->extraInputAttributes(['class' => 'bg-gray-100']),
                                TextInput::make('total_sell') // Mapped to DB total_sell
                                    ->label('Venta Total (USD)')
                                    ->numeric()
                                    ->prefix('USD')
                                    ->readOnly()
                                    ->extraInputAttributes(['class' => 'bg-gray-100']),
                                TextInput::make('profit')
                                    ->label('Ganancia (USD)')
                                    ->numeric()
                                    ->prefix('USD')
                                    ->readOnly()
                                    ->extraInputAttributes(['class' => 'bg-gray-100 font-bold text-success-600']),
                            ]),
                    ]),
            ]);
    }

    protected static function getCurrencyLabel(mixed $currency): string
    {
        if ($currency instanceof Currency) {
            return $currency->value;
        }

        return (string) ($currency ?? 'USD');
    }

    public static function updateTotals(Set $set, Get $get): void
    {
        $items = $get('items') ?? [];

        $totalCostArs = 0;
        $totalSellArs = 0;

        $totalCostUsd = 0;
        $totalSellUsd = 0;

        foreach ($items as $item) {
            $currency = self::getCurrencyLabel($item['currency'] ?? 'USD');
            $rate = (float) ($item['exchange_rate'] ?? 1);
            $cost = (float) ($item['cost'] ?? 0);
            $sell = (float) ($item['sell'] ?? 0);

            if ($currency === Currency::USD->value) {
                $totalCostUsd += $cost;
                $totalSellUsd += $sell;
            } elseif ($currency === Currency::ARS->value) {
                $totalCostArs += $cost;
                $totalSellArs += $sell;
            } else {
                // Other currencies (e.g. BRL) fallback to USD conversion?
                // Or just ignore? Assuming simple ARS/USD split for now as per user request.
                // If Rate is provided, we can convert to USD.
                if ($rate > 0) {
                    // Assume rate is to USD (e.g. BRL->USD 5.5) -> Amount / Rate
                    // OR Amount * Rate if Rate is "USD value".
                    // Let's Convert everything else to USD for the USD bucket.
                    $totalCostUsd += ($cost / $rate);
                    $totalSellUsd += ($sell / $rate);
                }
            }
        }

        // Set Display Values
        $set('total_cost_ars_display', number_format($totalCostArs, 2, '.', ''));
        $set('total_sell_ars_display', number_format($totalSellArs, 2, '.', ''));
        $set('profit_ars_display', number_format($totalSellArs - $totalCostArs, 2, '.', ''));

        // Set DB Values (USD bucket)
        $set('total_cost', number_format($totalCostUsd, 2, '.', ''));
        $set('total_sell', number_format($totalSellUsd, 2, '.', ''));
        $set('profit', number_format($totalSellUsd - $totalCostUsd, 2, '.', ''));
    }
}
